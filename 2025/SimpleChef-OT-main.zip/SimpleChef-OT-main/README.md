# SimpleChef-OT
SimpleChef OT Projekti React,TSX,Express,PostgreSQL,Prisma,Swagger,JWT,Bcrypt
