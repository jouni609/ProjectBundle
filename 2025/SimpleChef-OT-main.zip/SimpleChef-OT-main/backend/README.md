Backendiin asennettavat paketit:
    npm install

Prisman ensimmäinen luominen
    Luo .env kansio .env.examplen mukaan
    npm i lataa kaikki tarvittavat depenssit
    npm run prisma:generate generoi prisma instanssin
    npm run dev käynnistää backend serverin