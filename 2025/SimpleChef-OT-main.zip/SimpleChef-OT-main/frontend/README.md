# React + TypeScript + Vite
Ennen sovelluksen käynnistystä
npm i asentaa tarvittavat teknologiat
npm run dev käynnistää frontend serverin
